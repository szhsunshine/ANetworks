--[===[@debug@
GAME_LOCALE="itIT"
--@end-debug@]===]
